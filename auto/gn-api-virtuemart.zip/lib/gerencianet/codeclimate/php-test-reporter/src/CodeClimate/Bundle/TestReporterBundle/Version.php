<?php
namespace CodeClimate\Bundle\TestReporterBundle;

/**
 * TestReporterBundle version.
 */
final class Version
{
    /**
     * TestReporter version.
     *
     * @var string
     */
    const VERSION = '0.1.2';
}
