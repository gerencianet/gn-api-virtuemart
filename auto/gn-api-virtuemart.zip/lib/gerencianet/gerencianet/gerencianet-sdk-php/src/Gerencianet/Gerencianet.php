<?php

namespace Gerencianet;

class Gerencianet extends Endpoints
{
}
